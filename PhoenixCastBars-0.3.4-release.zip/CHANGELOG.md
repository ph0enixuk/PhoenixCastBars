# Changelog

## [0.3.4] - 2026-01-18
### Changed
- Bumped addon version to 0.3.4.

### Fixed
- Restored missing generic profile dropdown helper to avoid runtime error when rendering Profiles.
- Immediate UI refresh for options when toggling per-bar override checkboxes.

### Added
- Inline per-bar override controls for Player/Target/Focus (texture/font/outline).

## [0.3.3]
- UI and options refactor: per-bar overrides, inline dropdowns, dropdown helper internals exposed.
